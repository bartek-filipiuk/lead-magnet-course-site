# Verification Prompt

**Niezależny prompt audytowy.** Wklej go do DOWOLNEGO agenta AI (Claude Code, Cursor, Windsurf, ChatGPT — cokolwiek używasz) w katalogu swojego projektu, żeby sprawdzić aktualny stan.

---

Przeczytaj pliki `ARTIFACT_CHECKLIST.md` i `HANDOFF_STAGES_PLAN.md` w tym projekcie.
Następnie wykonaj pełny audyt:

1. **Wylistuj WSZYSTKIE pliki** w katalogu projektu (rekursywnie, pomijając `node_modules`, `.git`, `__pycache__`, `dist`, `.next`).

2. **Dla każdego artefaktu z `ARTIFACT_CHECKLIST.md`** sprawdź:
   - Czy plik istnieje?
   - Jeśli tak: czy zawiera wymagane sekcje?
   - Jeśli nie: oznacz jako **BRAK**

3. **Otwórz `HANDOFF_STAGES_PLAN.md`** i policz:
   - Ile tasków ma `[x]` (ukończone)
   - Ile tasków ma `[ ]` (nieukończone)
   - Czy każdy stage ma sekcję/task **Security**?
   - Czy każdy stage ma sekcję/task **Docs & Self-check**?

4. **Sprawdź kod źródłowy** pod kątem hardcoded secrets:
   - Przeszukaj pliki `.py`, `.ts`, `.js`, `.tsx`, `.jsx`, `.env.example` pod kątem: `API_KEY=`, `PASSWORD=`, `SECRET=`, `TOKEN=` z wartością (nie placeholder)
   - Sprawdź czy `.env` jest w `.gitignore`

5. **Sprawdź git:**
   - Czy repo jest zainicjalizowane? (`git status`)
   - Ile commitów? (`git log --oneline`)
   - Czy commity odpowiadają stage'om?

6. **Wygeneruj raport w poniższym formacie:**

---

## Raport weryfikacji projektu

**Data:** [YYYY-MM-DD]
**Faza:** [określ na podstawie istniejących artefaktów — Phase 1/2/3 Stage N/4/5]

### Artefakty

| Plik | Status | Uwagi |
|------|--------|-------|
| `PRD.md` | ✓ / ✗ | ... |
| `TECH_STACK.md` | ✓ / ✗ | ... |
| `HANDOFF_STAGES_PLAN.md` | ✓ / ✗ | ... |
| `.gitignore` | ✓ / ✗ | ... |
| `docs/README.md` | ✓ / ✗ | ... |
| `docs/API.md` | ✓ / ✗ | ... |
| `docs/CHANGELOG.md` | ✓ / ✗ | ... |
| `docs/SECURITY.md` | ✓ / ✗ / N/A | ... |
| `Caddyfile` | ✓ / ✗ / N/A | ... |
| `docker-compose.yml` | ✓ / ✗ | ... |
| `Dockerfile` | ✓ / ✗ | ... |

### Postęp HANDOFF_STAGES_PLAN.md

- Ukończone: **X/Y** tasków (**Z%**)
- Security tasks: obecne w **N/M** stage'ów
- Docs & Self-check tasks: obecne w **N/M** stage'ów
- Stages z 100% ukończeniem: **lista**

### Git

- Repo zainicjalizowane: ✓ / ✗
- Liczba commitów: N
- Commity per stage: ✓ / ✗

### Problemy do naprawienia

1. [Lista brakujących artefaktów]
2. [Lista niekompletnych sekcji]
3. [Znalezione hardcoded secrets — jeśli są]

### Rekomendacje

[Co zrobić dalej, żeby projekt był zgodny z wymaganiami kursu]
